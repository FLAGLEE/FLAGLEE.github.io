# MergeNav V1.1
## -s
stream type
read stream_path\out_path\out_file_prefix from stream.txt
e.g.    ./MergeNav -s
	
## -f
file type
read stream_path\out_path\out_file_prefix from file.txt
e.g.	./MergeNav -f
	
## -p
self-define output file prefix
e.g.	./MergeNav -p WHUSGG
out:		WHUSGG.20p
default:	brdcDOY0.20p
	
## -o
output path
e.g.	./MergeNav -o ./Result/
	
## other
input file path



# e.g. 
## read file from cmd
./MergeNav -p LQZcmdflie -o ./Result/ ./RTCM3/HH0012.2020330binRTCM3 ./RTCM3/HH0013.2020330binRTCM3 
	
## read stream from stream.txt
./MergeNav -s
./MergeNav -s -p LQZstreamfile
./MergeNav -s -p LQZstreamfile -o ./Result/
	

## read file from file.txt
./MergeNav -f
./MergeNav -f -p LQZfilefile
./MergeNav -f -p LQZfilefile -o ./Result/


# ver log
## 1.0
## 1.1
- add file auto stop
- add linux version
